%% Simulink 3D Animation with Moving Target
figure;
width = 600;
height = 600;
NewFigure(-45,30,width,height);
pause(1);

AnimEuler(out.t, XYZs, 10*ts);


%% Local Functions

function NewFigure(viewx,viewy,w,h)
    %set(gca, 'XLim', xlim,'YLim',ylim,'ZLim',zlim);
    view(viewx,viewy)
    x0=10;
    y0=10;
    set(gcf,'position',[x0,y0,w,h])
    
    [C1,C2,C3] = sphere;
    R_Earth = 6371*1000;
    
    C11 = C1*R_Earth;
    C22 = C2*R_Earth;
    C33 = C3*R_Earth;  
    s = surf(C11,C22,C33,'FaceAlpha',0.2,'EdgeColor','none');
    %alpha 0.5;
    
    clear C1;
    clear C2;
    clear C3;
    
    hold on;
    grid on;
end

function AnimEuler(tt,XYZs, ts)
    %curve = animatedline('LineWidth',1.5);
    
    Pts = gobjects(length(XYZs),1);
    Cur = gobjects(length(XYZs),1);
    for k = 1:length(XYZs)
        Cur(k) = animatedline('LineWidth',1.5);
    end
    
    %scatter3(0,0,0,1000,'blue','filled')   
    
    
    t_section = 0;
    % Do Animation
    for i = 1:length(tt)-1
        if abs( tt(i) - t_section) < 0.0001
            
            for j = 1:length(XYZs)
                curve = Cur(j);
                XYZss = XYZs{1,j};
                
                XYZ = XYZss(i,:);
                       
                % Draw
                Pts(j) = scatter3(XYZ(1),XYZ(2),XYZ(3),'filled');
                addpoints(curve, XYZ(1), XYZ(2),XYZ(3));
                
            end
            
            drawnow
            pause(0.05)
            axis equal;
            
            delete(Pts);
                      
            t_section = t_section + ts;
           
        end
    end
end








