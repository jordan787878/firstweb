% Chun-Wei, Kong
% j2855001@gmail.com
% 2021.08.06


clear all;
clc;

% Number of Orbit Object
N_Obj = 6;
TWE = zeros(N_Obj,5);

% Input Two-line element set as:
% [inclination, Right Ascension, Eccentricity, Argument of Perigee, Mean
% motion]
TWE(1,:) = [51.6443,97.1528,0.0001215,252.4511,15.48878547]; %ISS
TWE(2,:) = [28.4699,101.3108,0.0002592,227.2076,15.09697538]; %HST
TWE(3,:) = [2.6372,77.2298,0.0003026,63.4510,1.00149818]; %SYNCOM3 
TWE(4,:) = [55.4781,168.0086,0.0050341,53.2841,2.00562504]; %GPS BIIR-2
TWE(5,:) = [56.8638,29.9694,0.0002680,52.5538,1.70475404]; %GSAT0101
TWE(6,:) = [98.6506,178.7277,0.0033756,133.5391,14.37807943]; %ERS-1 

%% Kepler Orbit Elemets
e = TWE(:,3);
% Orientation
RAAN = TWE(:,2)*pi/180;
INCL = TWE(:,1)*pi/180;
AROP = TWE(:,4)*pi/180;
% n: mean motion, [REV per Day]
n = TWE(:,5);


T_REV = 24*60*60./n;
n_rad_s = 2*pi./T_REV;

G = 6.6743e-11;
m_Earth = 5.912e+24;
mu = m_Earth*G;   % mu = G*(m1+m2)
% mu = a^3*n^2, n[rad/s]
a = (mu./(n_rad_s).^2).^(1/3);

c = a.*e;
b = a.*sqrt(1-e.^2);

% % Preview 2D plot of orbit
% t = 0:15*pi/180:2*pi;
% for i = 1:N_Obj
% x = a(i)*cos(t);
% y = b(i)*sin(t);
% 
% plot(x,y,'LineWidth',3); hold on;
% scatter(c(i),0,'blue','filled'); hold on;
% 
% axis equal;
% grid on;
% 
% end
% 
% % Draw orbit by radius and true anomaly
% % find p
% p = a.*(1-e.^2);
% 
% f = 0:3*pi/180:2*pi;
% r = p.*(1+e*cos(f)).^(-1);
% 
% for i=1:N_Obj
% 
% x_rf = c(i) + r(i).*cos(f);
% y_rf = r(i).*sin(f);
% plot(x_rf,y_rf,':','LineWidth',2); hold on;
% axis equal;
% 
% end


%% Calculte Initial States
r0 = a-c;
v0 = sqrt(mu*((2./r0)-(1./a)));
% a_check = 1/(2./r0-v0.^2/mu);
% p_check = (r0.*v0).^2/mu;
%
r0s = zeros(N_Obj,3);
v0s = zeros(N_Obj,3);
for i = 1:N_Obj
    r0s(i,1) = r0(i);
    v0s(i,2) = v0(i);
end

% time step of simulation
ts = 20;

%% Simulation
clear out;
clc;
out = sim('Kepler',86400);

% %% Scatter r, f
% r1 = transpose(squeeze(out.r(1,:,:)));
% plot(r1(:,1),r1(:,2));
% axis equal;


%% Orbit Elements
XYZs = {};
for i = 1:N_Obj
    Data = transpose(squeeze(out.r(i,:,:)));
    T_BtoI = BtoI(RAAN(i),INCL(i),AROP(i));
    XYZs{end+1} = transpose(T_BtoI*transpose(Data));
end

% 3D animation
Anim_ISS;

%% Local Function
function m = BtoI(a,b,c)
    R_ItoV1= [[cos(a) sin(a) 0];[-sin(a) cos(a) 0];[0 0 1]];
    R_V1toV2 = [[1 0 0];[0 cos(b) sin(b)];[0 -sin(b) cos(b)]];
    R_V2toB = [[cos(c) sin(c) 0];[-sin(c) cos(c) 0];[0 0 1]];
    
    m = R_V2toB*R_V1toV2*R_ItoV1;
    m = transpose(m);
end


