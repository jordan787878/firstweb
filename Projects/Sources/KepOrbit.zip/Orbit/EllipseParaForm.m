% Ellipse Basic Geometry Study
% Ellipse Parametric form
a = 3;
b = 2;

t = 0:15*pi/180:2*pi;
x = a*cos(t);
y = b*sin(t);
z = a*sin(t);
w = b*cos(t);
r = sqrt(x.*x + y.*y);

plot(x,y,'LineWidth',3);
hold on;
plot(x,z);
hold on;
plot(w,y);
hold on;

i = 5;
plot([0,x(i)],[0,y(i)]); hold on;
plot([0,x(i)],[0,z(i)]); hold on;
plot([0,w(i)],[0,y(i)]); hold on;
plot([x(i),x(i)],[z(i),0],'black:'); hold on;
plot([x(i),w(i)],[y(i),y(i)],'black:'); hold on;
plot([0,x(1)],[0,0],'black:'); hold on;
scatter(x(i),y(i),'black','filled');
grid on;

% Use r: radius and f: true anomaly to define ellipse
% find c,e
c = sqrt(a^2-b^2);
e = c/a;

% find p
p = a*(1-e^2);
scatter(c,0,'blue','filled')

f = 0:3*pi/180:2*pi;
r = p.*(1+e*cos(f)).^(-1);

x_rf = a*e + r.*cos(f);
y_rf = r.*sin(f);
plot(x_rf,y_rf,'red:','LineWidth',2)




